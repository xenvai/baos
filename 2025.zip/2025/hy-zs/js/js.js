document.addEventListener('DOMContentLoaded', function() {
    const toggler = document.querySelector('.navbar-toggler');
    const collapse = document.querySelector('.navbar-collapse');
    
    toggler.addEventListener('click', function() {
      this.classList.toggle('active');
      collapse.classList.toggle('active');
    });
    
    // 点击菜单项后自动关闭菜单 (移动端)
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', function() {
        if (window.innerWidth <= 768) {
          toggler.classList.remove('active');
          collapse.classList.remove('active');
        }
      });
    });
  });



  /*文章js */

  
  document.addEventListener('DOMContentLoaded', function() {
    // 获取文章列表
    const articleList = document.querySelector('.article-list');
    
    if (articleList) {
      // 获取所有文章项
      const articles = articleList.querySelectorAll('.article-item');
      
      // 如果超过10条，隐藏多余的
      if (articles.length > 10) {
        for (let i = 10; i < articles.length; i++) {
          articles[i].style.display = 'none';
        }
        
        // 可选：添加"查看更多"按钮
        const moreButton = document.createElement('button');
        moreButton.className = 'show-more-btn';
        moreButton.textContent = '查看更多文章';
        articleList.parentNode.appendChild(moreButton);
        
        moreButton.addEventListener('click', function() {
          for (let i = 10; i < articles.length; i++) {
            articles[i].style.display = 'flex';
          }
          moreButton.style.display = 'none';
        });
      }
    }
  });
  