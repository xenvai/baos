document.addEventListener('DOMContentLoaded', function() {
    // 限制相关文章显示条数
    const relatedList = document.querySelector('.related-list');
    const maxItems = 5; // 最多显示5条相关文章
    
    if (relatedList && relatedList.children.length > maxItems) {
      const relatedItems = relatedList.querySelectorAll('.related-item');
      
      // 隐藏超出数量的条目
      for (let i = maxItems; i < relatedItems.length; i++) {
        relatedItems[i].style.display = 'none';
      }
      
      // 添加"显示更多"按钮
      const showMoreBtn = document.createElement('button');
      showMoreBtn.className = 'show-more-btn';
      showMoreBtn.textContent = '显示更多相关文章';
      relatedList.parentNode.appendChild(showMoreBtn);
      
      showMoreBtn.addEventListener('click', function() {
        for (let i = maxItems; i < relatedItems.length; i++) {
          relatedItems[i].style.display = 'block';
        }
        showMoreBtn.style.display = 'none';
      });
    }
  });