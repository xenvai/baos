document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    // 移动菜单切换
    mobileMenuBtn.addEventListener('click', function() {
        navLinks.classList.toggle('active');
        
        // 切换图标
        const icon = this.querySelector('i');
        if (navLinks.classList.contains('active')) {
            icon.classList.remove('fa-bars');
            icon.classList.add('fa-times');
        } else {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }
    });
    
    // 点击导航链接后关闭菜单（移动端）
    const navItems = document.querySelectorAll('.nav-links a');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if (window.innerWidth <= 992) {
                navLinks.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    });
    
    // 窗口大小改变时检查是否需要隐藏菜单
    window.addEventListener('resize', function() {
        if (window.innerWidth > 992) {
            navLinks.classList.remove('active');
            const icon = mobileMenuBtn.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }
    });
});
//轮播图js代码开始的地

document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    const indicators = document.querySelectorAll('.indicator');
    let currentIndex = 0;
    let intervalId;
    
    // 更新幻灯片位置
    function updateSlidePosition() {
        const slideWidth = slides[0].clientWidth;
        document.querySelector('.carousel-slides').style.transform = `translateX(-${currentIndex * slideWidth}px)`;
        
        // 更新指示器状态
        indicators.forEach((indicator, index) => {
            indicator.classList.toggle('active', index === currentIndex);
        });
    }
    
    // 切换到下一张
    function nextSlide() {
        currentIndex = (currentIndex + 1) % slides.length;
        updateSlidePosition();
    }
    
    // 切换到上一张
    function prevSlide() {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        updateSlidePosition();
    }
    
    // 自动轮播
    function startAutoSlide() {
        intervalId = setInterval(nextSlide, 3000);
    }
    
    // 停止自动轮播
    function stopAutoSlide() {
        clearInterval(intervalId);
    }
    
    // 事件监听
    nextBtn.addEventListener('click', () => {
        nextSlide();
        stopAutoSlide();
        startAutoSlide();
    });
    
    prevBtn.addEventListener('click', () => {
        prevSlide();
        stopAutoSlide();
        startAutoSlide();
    });
    
    // 点击指示器跳转
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            currentIndex = index;
            updateSlidePosition();
            stopAutoSlide();
            startAutoSlide();
        });
    });
    
    // 鼠标悬停暂停
    document.querySelector('.carousel-container').addEventListener('mouseenter', stopAutoSlide);
    document.querySelector('.carousel-container').addEventListener('mouseleave', startAutoSlide);
    
    // 触摸设备支持
    let touchStartX = 0;
    let touchEndX = 0;
    
    document.querySelector('.carousel-slides').addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoSlide();
    });
    
    document.querySelector('.carousel-slides').addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
        startAutoSlide();
    });
    
    function handleSwipe() {
        if (touchEndX < touchStartX - 50) {
            nextSlide(); // 向左滑动
        } else if (touchEndX > touchStartX + 50) {
            prevSlide(); // 向右滑动
        }
    }
    
    // 窗口大小改变时重新计算
    window.addEventListener('resize', updateSlidePosition);
    
    // 初始化
    updateSlidePosition();
    startAutoSlide();
});


//图片排列

document.addEventListener('DOMContentLoaded', function() {
    const gallery = document.querySelector('.horizontal-gallery');
    const galleryItems = document.querySelectorAll('.gallery-item');
    const prevButton = document.querySelector('.prev-button');
    const nextButton = document.querySelector('.next-button');
    const pagination = document.querySelector('.gallery-pagination');
    
    let currentIndex = 0;
    let isDragging = false;
    let startX = 0;
    let scrollLeft = 0;
    
    // 创建分页指示器
    function createPagination() {
        galleryItems.forEach((_, index) => {
            const dot = document.createElement('div');
            dot.classList.add('pagination-dot');
            if (index === 0) dot.classList.add('active');
            dot.dataset.index = index;
            pagination.appendChild(dot);
            
            dot.addEventListener('click', function() {
                goToSlide(parseInt(this.dataset.index));
            });
        });
    }
    
    // 更新分页状态
    function updatePagination() {
        const dots = document.querySelectorAll('.pagination-dot');
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    }
    
    // 滚动到指定幻灯片
    function goToSlide(index) {
        currentIndex = index;
        const itemWidth = galleryItems[0].offsetWidth;
        const gap = 20; // 与CSS中的gap值一致
        gallery.scrollTo({
            left: index * (itemWidth + gap),
            behavior: 'smooth'
        });
        updatePagination();
    }
    
    // 下一张
    function nextSlide() {
        currentIndex = (currentIndex + 1) % galleryItems.length;
        goToSlide(currentIndex);
    }
    
    // 上一张
    function prevSlide() {
        currentIndex = (currentIndex - 1 + galleryItems.length) % galleryItems.length;
        goToSlide(currentIndex);
    }
    
    // 自动播放
    let autoPlayInterval;
    function startAutoPlay() {
        autoPlayInterval = setInterval(nextSlide, 5000);
    }
    
    function stopAutoPlay() {
        clearInterval(autoPlayInterval);
    }
    
    // 鼠标/触摸事件处理
    gallery.addEventListener('mousedown', (e) => {
        isDragging = true;
        startX = e.pageX - gallery.offsetLeft;
        scrollLeft = gallery.scrollLeft;
        stopAutoPlay();
    });
    
    gallery.addEventListener('mouseleave', () => {
        isDragging = false;
        startAutoPlay();
    });
    
    gallery.addEventListener('mouseup', () => {
        isDragging = false;
        calculateCurrentSlide();
        startAutoPlay();
    });
    
    gallery.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        e.preventDefault();
        const x = e.pageX - gallery.offsetLeft;
        const walk = (x - startX) * 2; // 调整滑动速度
        gallery.scrollLeft = scrollLeft - walk;
    });
    
    // 触摸事件
    gallery.addEventListener('touchstart', (e) => {
        isDragging = true;
        startX = e.touches[0].pageX - gallery.offsetLeft;
        scrollLeft = gallery.scrollLeft;
        stopAutoPlay();
    });
    
    gallery.addEventListener('touchend', () => {
        isDragging = false;
        calculateCurrentSlide();
        startAutoPlay();
    });
    
    gallery.addEventListener('touchmove', (e) => {
        if (!isDragging) return;
        const x = e.touches[0].pageX - gallery.offsetLeft;
        const walk = (x - startX) * 2;
        gallery.scrollLeft = scrollLeft - walk;
    });
    
    // 计算当前显示的幻灯片
    function calculateCurrentSlide() {
        const itemWidth = galleryItems[0].offsetWidth;
        const gap = 20;
        const scrollPosition = gallery.scrollLeft;
        
        currentIndex = Math.round(scrollPosition / (itemWidth + gap));
        updatePagination();
    }
    
    // 滚动事件监听
    gallery.addEventListener('scroll', () => {
        if (!isDragging) {
            calculateCurrentSlide();
        }
    });
    
    // 按钮事件
    prevButton.addEventListener('click', () => {
        prevSlide();
        stopAutoPlay();
        startAutoPlay();
    });
    
    nextButton.addEventListener('click', () => {
        nextSlide();
        stopAutoPlay();
        startAutoPlay();
    });
    
    // 键盘导航
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
            stopAutoPlay();
            startAutoPlay();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
            stopAutoPlay();
            startAutoPlay();
        }
    });
    
    // 初始化
    createPagination();
    startAutoPlay();
    
    // 响应式调整
    window.addEventListener('resize', () => {
        const itemWidth = galleryItems[0].offsetWidth;
        const gap = 20;
        gallery.scrollTo({
            left: currentIndex * (itemWidth + gap),
            behavior: 'smooth'
        });
    });
});