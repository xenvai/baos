document.addEventListener('DOMContentLoaded', function() {
    // 限制精选文章显示10条
    const featuredList = document.querySelector('.article-list');
    if (featuredList && featuredList.children.length > 10) {
      const featuredItems = featuredList.querySelectorAll('.article-item');
      for (let i = 10; i < featuredItems.length; i++) {
        featuredItems[i].style.display = 'none';
      }
      
      // 添加"加载更多"按钮
      const loadMoreBtn = document.createElement('button');
      loadMoreBtn.className = 'load-more-btn';
      loadMoreBtn.textContent = '查看更多精彩内容';
      featuredList.parentNode.appendChild(loadMoreBtn);
      
      loadMoreBtn.addEventListener('click', function() {
        for (let i = 10; i < featuredItems.length; i++) {
          featuredItems[i].style.display = 'block';
        }
        loadMoreBtn.style.display = 'none';
      });
    }
    
    // 限制最新文章显示10条
    const latestList = document.querySelector('.latest-list');
    if (latestList && latestList.children.length > 10) {
      const latestItems = latestList.querySelectorAll('.latest-item');
      for (let i = 10; i < latestItems.length; i++) {
        latestItems[i].style.display = 'none';
      }
    }
  });



  /*左边内容js */

  document.addEventListener('DOMContentLoaded', function() {
    // 限制精选文章显示10条
    const featuredList = document.querySelector('latest-list');
    if (featuredList && featuredList.children.length > 10) {
      const featuredItems = featuredList.querySelectorAll('latest-list');
      for (let i = 10; i < featuredItems.length; i++) {
        featuredItems[i].style.display = 'none';
      }
      
      // 添加"加载更多"按钮
      const loadMoreBtn = document.createElement('button');
      loadMoreBtn.className = 'load-more-btn';
      loadMoreBtn.textContent = '查看更多精彩内容';
      featuredList.parentNode.appendChild(loadMoreBtn);
      
      loadMoreBtn.addEventListener('click', function() {
        for (let i = 10; i < featuredItems.length; i++) {
          featuredItems[i].style.display = 'block';
        }
        loadMoreBtn.style.display = 'none';
      });
    }
    
    // 限制最新文章显示10条
    const latestList = document.querySelector('.latest-list');
    if (latestList && latestList.children.length > 10) {
      const latestItems = latestList.querySelectorAll('.latest-list');
      for (let i = 10; i < latestItems.length; i++) {
        latestItems[i].style.display = 'none';
      }
    }
  });